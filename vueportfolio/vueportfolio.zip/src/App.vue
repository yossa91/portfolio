<template>
  <div>
    <router-view></router-view>    
  </div>
</template>

<script>

</script>

<style>


</style>
