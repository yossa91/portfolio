<template>
    <main>
        <div id="introWrap">
            <div class="introMain">
                <span class="introMainClose"></span>
                <a class="introIcoHome"></a>
                <a class="introIcoSidemenu"></a>
                <div class="introSideMenu">
                    <div><a class="ism_btn"></a></div>
                    <ul>
                        <li><a class="introPage">intro</a></li>
                        <li><a class="makerPage">maker</a></li>
                        <li class="sideMenuResult">results</li>
                            <ul>
                                <li><a class="menuCheck">renewalSite</a></li>
                                <li><a class="clonePage">cloneSite</a></li>
                                <li><a class="designPage">otherDesign</a></li>
                                <li><a class="contactPage">contact</a></li>
                            </ul>                        
                    </ul>
                </div>
                <div class="content"><!--본문-->
                    <article class="contentTitile">
                        <span>RESULTS</span>
                        <h3>RENEWAL SITE</h3>
                        <p>웹 리뉴얼 사이트</p>
                    </article>
                    <article class="contentBox">
                        <section>
                            <div class="ctBoxPhoto cbp01"></div>
                                <div class="ctBoxInfo">
                                    <h4><span>01</span>노원문화원 웹 리뉴얼 사이트</h4>
                                    <p><span>Viewport</span>반응형</p>
                                    <p><span>Part</span>Main Section04, Intro Category Page, Login Page</p>
                                    <p class="ctBoxInfoTxt">
                                        전체적으로 정리되어 보이지 않는 배너들로 페이지의 첫페이지가 혼란스러워 보이며
                                        아쉬운 반응형 부분과 단색의 이미지들의 아쉬운 부분을 개선하여
                                        제작하려 노력하였습니다.<br/>
                                        리뉴얼 사이트는 팀 프로젝트로 진행되었으며 메인페이지의 4section과 footer, Intro Category
                                        내 페이지, 로그인 페이지와 회원가입 페이지 제작부분을 맡아 진행하였습니다.
                                    </p>
                                    <a class="ctBoxMockupBtn">Mockup</a>
                                    <a class="ctBoxDemoBtn" href="https://nw5jo.herokuapp.com/" target="_blank">Demo</a>
                                    <a class="ctBoxReposBtn" href="https://github.com/yossa91/projectNw" target="_blank">Repos</a>
                                </div>
                                <div class="ctBoxSkill">
                                    <table>
                                        <colgroup>
                                            <col width = '15%'>
                                            <col width = '*'>
                                            <col width = '25%'>
                                        </colgroup>
                                        <tr>
                                            <th>Category</th>
                                            <th>Source</th>
                                            <th>Skills</th>
                                        </tr>
                                        <tr>
                                            <td class="tb_cate tb_c_ejs"><span>EJS</span></td>
                                            <td>main.ejs / nowon_intro...ejs / nowon_iC_...ejs / nowon_login...ejs</td>
                                            <td>html,ejs</td>
                                        </tr>
                                        <tr>
                                            <td class="tb_cate tb_c_css"><span>CSS</span></td>
                                            <td>main.css / nowon_intro...css / nowon_iC_...css / nowon_login...css</td>
                                            <td>css</td>
                                        </tr>
                                        <tr>
                                            <td class="tb_cate tb_c_js"><span>JS</span></td>
                                            <td>main.js / signup.js</td>
                                            <td>JavaScript,Nodejs</td>
                                        </tr>
                                        <tr>
                                            <td class="tb_cate tb_c_mysql"><span>MYSQL</span></td>
                                            <td>nowon_introConduct Page</td>
                                            <td>MySQL,Heroku</td>
                                        </tr>
                                    </table>
                                </div>
                        </section>
                        <section>
                            <div class="ctBoxPhoto cbp02"></div>
                                <div class="ctBoxInfo">
                                    <h4><span>02</span>서문시장야시장 웹 리뉴얼 사이트</h4>
                                    <p><span>Viewport</span>반응형</p>
                                    <p><span>Part</span>All</p>
                                    <p class="ctBoxInfoTxt">
                                        다소 오래되어 보이는 디자인에 통합 될 수 있는 메뉴들과 복잡한 이미지를 개섢하고자
                                        리뉴얼을 계획하게 되었습니다.<br/>
                                        중심이 되는 페이지를 중심으로 메인 페이지를 깔끔하게 제작하고 각 페이지 별 사이트 접속의
                                        주요 목적을 충족시킬 수 있도록 제작하려 노력했으며, 반응형으로 다양한 기기에서 최적화
                                        될 수 있도록 제작하려 노력하였습니다.
                                    </p>
                                    <a class="ctBoxMockupBtn">Mockup</a>
                                    <a class="ctBoxDemoBtn" href="https://sumoontester.herokuapp.com/" target="_blank">Demo</a>
                                    <a class="ctBoxReposBtn" href="https://github.com/yossa91/projectSm" target="_blank">Repos</a>
                                </div>
                                <div class="ctBoxSkill">
                                    <table>
                                        <colgroup>
                                            <col width = '15%'>
                                            <col width = '*'>
                                            <col width = '25%'>
                                        </colgroup>
                                        <tr>
                                            <th>Category</th>
                                            <th>Source</th>
                                            <th>Skills</th>
                                        </tr>
                                        <tr>
                                            <td class="tb_cate tb_c_ejs"><span>EJS</span></td>
                                            <td>layout.ejs / Seomun_intro.ejs / Seomun_list.ejs / Seomun_notice...ejs / singup_...ejs </td>
                                            <td>html,ejs</td>
                                        </tr>
                                        <tr>
                                            <td class="tb_cate tb_c_css"><span>CSS</span></td>
                                            <td>main.css / intro...css / nowon_iC_...css / nowon_login...css</td>
                                            <td>css</td>
                                        </tr>
                                        <tr>
                                            <td class="tb_cate tb_c_js"><span>JS</span></td>
                                            <td>kakao.js / main.js</td>
                                            <td>JavaScript,Nodejs,KakaoAPI</td>
                                        </tr>
                                        <tr>
                                            <td class="tb_cate tb_c_mysql"><span>MYSQL</span></td>
                                            <td>Seomun_notice Page</td>
                                            <td>MySQL,Heroku</td>
                                        </tr>
                                    </table>
                                </div>
                        </section>
                        <section>
                            <div class="ctBoxPhoto cbp03"></div>
                                <div class="ctBoxInfo">
                                    <h4><span>03</span>그린씽 웹 리뉴얼 사이트</h4>
                                    <p><span>Viewport</span>반응형</p>
                                    <p><span>Part</span>All</p>
                                    <p class="ctBoxInfoTxt">
                                        통일감이 낮은 레이아웃과 다소 오래되어 보이는 디자인은 번잡해보이며 중복되는 배너,
                                        혼란을 줄 수 있는 메뉴 링크를 개선 하고자 리뉴얼 제작을 계획하게 되었습니다.<br/>
                                        현장을 느낄 수 있는 메인페이지와 소개페이지, 판매처 리스트 페이지, 검색과 이벤트 안내 등 
                                        사이트 접속의 주요 목적을 충족시킬 수 있도록 노력한 qna게시판, 로그인과 가입 페이지를
                                        반응형으로 리뉴얼 하였습니다.
                                    </p>
                                    <a class="ctBoxMockupBtn">Mockup</a>
                                    <a class="ctBoxDemoBtn" href="https://greenssing.herokuapp.com/" target="_blank">Demo</a>
                                    <a class="ctBoxReposBtn" href="https://github.com/yossa91/projectGs" target="_blank">Repos</a>
                                </div>
                                <div class="ctBoxSkill">
                                    <table>
                                        <colgroup>
                                            <col width = '15%'>
                                            <col width = '*'>
                                            <col width = '25%'>
                                        </colgroup>
                                        <tr>
                                            <th>Category</th>
                                            <th>Source</th>
                                            <th>Skills</th>
                                        </tr>
                                        <tr>
                                            <td class="tb_cate tb_c_ejs"><span>EJS</span></td>
                                            <td>수정중----------</td>
                                            <td>html,ejs</td>
                                        </tr>
                                        <tr>
                                            <td class="tb_cate tb_c_css"><span>CSS</span></td>
                                            <td>수정중----------</td>
                                            <td>css</td>
                                        </tr>
                                        <tr>
                                            <td class="tb_cate tb_c_js"><span>JS</span></td>
                                            <td>수정중----------</td>
                                            <td>JavaScript,Nodejs,KakaoAPI</td>
                                        </tr>
                                        <tr>
                                            <td class="tb_cate tb_c_mysql"><span>MYSQL</span></td>
                                            <td>수정중----------</td>
                                            <td>MySQL,Heroku</td>
                                        </tr>
                                    </table>
                                </div>
                        </section>

                    </article>
                </div><!--content-->
                <div class="contentDetail"><!--본문모달-->
                    <div class="contentDtWrap">
                        <span class="contentDtWrapClose"></span>
                        <article class="contentDtEl">
                            <h4>노원문화원 웹 리뉴얼 사이트</h4>
                            <p>반응형 리뉴얼 사이트</p>
                            <img src="../assets/img/renewal/project_mockup_01.png" alt="">
                        </article>
                        <article class="contentDtEl">
                            <h4>서문시장야시장 웹 리뉴얼 사이트</h4>
                            <p>반응형 리뉴얼 사이트</p>
                            <img src="../assets/img/renewal/project_mockup_02.png" alt="">
                        </article>
                        <article class="contentDtEl">
                            <h4>그린씽 웹 리뉴얼 사이트</h4>
                            <p>반응형 리뉴얼 사이트</p>
                            <img src="" alt="">수정중----------
                        </article>
                    </div>
                </div><!--contentDetail-->
            </div><!--introMain-->
            <div class="project_bg_line">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2063.4 722.5">
                <path class="pj_bg_line" d="M6.7,10.6c0,0,168,106.2,223.5,182.8S294.8,312,270.7,351s-75.1,60.1-106.6,67.6s-43.5-18-21-55.6
                    s97.6-132.1,193.7-172.7s184.7-55.6,324.3-16.5s310.8,97.6,438.5,223.7s109.6,195.2,99.1,222.2c-10.5,27-30,63.9-1.5,85.2
                    c28.5,21.4,111.1-31.2,156.2-58.2c45-27,703.3-442.5,703.3-442.5"/>
                </svg>

            </div>
        </div><!--introWrap-->
    </main>
</template>



<script>

    export default{
        name : 'about-maker',
        mounted() {
                //목업버튼
                    var mockupBtn = document.querySelectorAll('.ctBoxMockupBtn');
                    var dtailArticl = document.querySelectorAll('.contentDtEl');
                    var mockupClose = document.querySelector('.contentDtWrapClose');
                    var scrollT = 0;

                    mockupBtn.forEach(function(el,idx){
                        el.addEventListener('click',function(){
                            //목업클로즈 시 원래 스크롤 위치로 이동을 위한 값
                            var sTop = document.querySelector('.introMain').scrollTop;
                            scrollT = sTop;
                            //목업 최상단이동
                            document.querySelector('.introMain').style.overflowY = 'hidden';
                            document.querySelector('.introMain').scrollTop = 0;
                            document.querySelector('.contentDetail').style.display = 'block';
                            document.querySelector('.contentDtWrap').scrollTop = 0;

                            for(var i =0 ; i < dtailArticl.length ; i++){
                                dtailArticl[i].style.display = 'none';
                            }
                            //목업 길이 내용물에 맞춰서
                            dtailArticl[idx].style.display = 'block';
                        });
                    });
                    //목업클로즈
                    mockupClose.addEventListener('click',() => {
                        console.log(scrollT);
                        document.querySelector('.contentDetail').style.display = 'none';
                        document.querySelector('.introMain').style.overflowY = 'scroll';
                        //목업클로즈 시 원래 스크롤 위치로 이동
                        document.querySelector('.introMain').scrollTop = scrollT;
                    });
                //사이드메뉴 열기,닫기
                var sideBtn = document.querySelector('.introIcoSidemenu');
                var sideMenu = document.querySelector('.introSideMenu');
                var sideClose = document.querySelector('.ism_btn');
                sideBtn.addEventListener('click',() => {
                    sideMenu.style.width = '300px';
                    document.querySelector('.introMain').style.overflowY = 'hidden';
                });
                sideClose.addEventListener('click', () => {
                    sideMenu.style.width = '0px';
                    document.querySelector('.introMain').style.overflowY = 'scroll';
                });
                //페이지 연결

                function moveList(page) {
                    document.querySelector('.pj_bg_line').className.baseVal = 'pj_bg_lineBack';                                     
                    setTimeout(() => {
                        document.querySelector('.introMainClose').style.opacity = 1;
                        document.querySelector('.introMainClose').style.zIndex = 99;
                            setTimeout(() => {
                               location.replace('/' + page);
                            }, 100);
                    }, 1000);
                }

                document.querySelector('.introIcoHome').addEventListener('click', () => {
                    moveList('home');
                });
                document.querySelector('.introPage').addEventListener('click', () => {
                    moveList('home');
                });
                document.querySelector('.makerPage').addEventListener('click', () => {
                    moveList('about');
                });
                document.querySelector('.clonePage').addEventListener('click', () => {
                    moveList('clone');
                });
                document.querySelector('.designPage').addEventListener('click', () => {
                    moveList('design');
                });
                document.querySelector('.contactPage').addEventListener('click', () => {
                    moveList('contact');
                }); 




        },
    }


</script>

<style scoped>
    main{
        width: 100%;
        height: 100vh; 
        background-color: #E5BE07;
        box-sizing: border-box;
        padding: calc(50vh - 400px) 0 0 0 ;
        overflow: hidden;
    } 
    #introWrap{
        width: 1200px;
        height: 800px;
        margin: auto;
        box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, .3);
        position: relative;
    }
    .introMain{
        width: 100%;
        height: 100%;
        position: relative;
        background-color:#FBF9EE ; 
        z-index: 5;
        overflow-y: scroll;
        scrollbar-color: #2C50FA rgba(255,255,255,0);
        scrollbar-width: thin;
    }
    .introMain::-webkit-scrollbar {
        width: 5px;
    }
    .introMain::-webkit-scrollbar-thumb {
        background-color: #2C50FA;
    }

    /*SVG~~~*/
    .project_bg_line{
        position: absolute;
        left: -400px;
        bottom: -150px;
    }    
    .project_bg_line>svg{
        width: 2050px;
    }
    .pj_bg_line{
        fill:none;stroke:#2C50FA;stroke-width:25;stroke-miterlimit:10;
        stroke-dasharray: 3150;
        stroke-dashoffset: 3150;
        animation-name:pjLineStart;
        animation-delay: 1.8s;
        animation-duration: 1.3s;
        animation-fill-mode: forwards;
        animation-timing-function:ease-in-out;
    }
    @keyframes pjLineStart{
    0% {stroke-dashoffset: 3150;}
    100% {stroke-dashoffset: 0;}
    }
    .pj_bg_lineBack{
        fill:none;stroke:#2C50FA;stroke-width:25;stroke-miterlimit:10;
        stroke-dasharray: 3150;
        stroke-dashoffset: 0;
        animation-name:pjLineBack;
        animation-duration: 0.8s;
        animation-fill-mode: forwards;
        animation-timing-function:ease-in-out;
    }
    @keyframes pjLineBack{
    0% {stroke-dashoffset: 0;}
    100% {stroke-dashoffset: 3150;}
    }
    /*페이지 이동 페이지 아웃*/
    .introMain .introMainClose{
        content: '';
        position: absolute;
        display: block;
        top:0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: -99;
        background-color: #FBF9EE;
        opacity: 0;
        transition: 0.2s;
    }
    /*아이콘들 픽스*/
    .introIcoHome , .introIcoSidemenu{
        display: block;
        width: 40px;
        height: 40px;
        position: absolute;
        background-size: 40px 40px;
        transition: 0.2s;
        opacity: 0;
        z-index: 50;
    }
    .introIcoHome{  
        background-image: url('../assets/img/intro/main_home.png');
        top:32px;
        left: 32px;
        animation-name: iconShow;
        animation-delay: 0.7s;
        animation-duration: 0.5s;
        animation-fill-mode: forwards;
    }
    .introIcoHome:hover{  
        background-image: url('../assets/img/intro/main_home_hv.png');
    }
    .introIcoSidemenu{
        background-image: url('../assets/img/intro/main_menu.png');
        top:32px;
        right: 32px;
        animation-name: iconShow;
        animation-delay: 1s;
        animation-duration: 0.3s;
        animation-fill-mode: forwards;
        cursor: pointer;
    }
    .introIcoSidemenu:hover{
        background-image: url('../assets/img/intro/main_menu_hv.png');
    }
    @keyframes iconShow {
        0%   {opacity: 0;}
        40%   {opacity: 1;}
        45%   {opacity: 0;}
        50%   {opacity: 1;}
        95%   {opacity: 0;}
        100%   {opacity: 1;}  
    }
    /*사이드메뉴*/
    .menuCheck{
        opacity: 0.6;
        text-decoration: underline;
    }
    .introSideMenu{
        position: absolute;
        z-index: 55;
        width: 0;
        right: 0;
        top:0;
        bottom: 0;
        background-color: #2C50FA;
        overflow: hidden;
        transition: 0.2s;
    }
    .introSideMenu>div{
        text-align: right;
        box-sizing: border-box;
        padding: 40px 20px 40px 0;
    }
    .introSideMenu>div>.ism_btn{
        display: inline-block;
        width: 40px;
        height: 40px;
        background: url('../assets/img/intro/main_close.png') center no-repeat;
        background-size: 25px auto;
        transition: 0.2s;
    }
    .introSideMenu>div>a:hover{
        opacity: 0.6;
    }
    .introSideMenu>ul{
        padding-left: 40px;
        font-weight: 300;
    }
    .introSideMenu>ul ul{
        padding:10px 0 0 20px;
    }
    .introSideMenu>ul a{
        cursor: pointer;
    }
    .introSideMenu .sideMenuResult{
        font-size: 15px;
        color: #fff;
        padding:7px 30px 7px 30px;
        background: url('../assets/img/intro/main_menu_side2.png')center left no-repeat;
        background-size: 16px auto;
    }
    .introSideMenu>ul a{
        display: inline-block;
        font-size: 15px;
        color: #fff;
        padding:7px 30px 7px 30px;
        background: url('../assets/img/intro/main_menu_side.png')center left no-repeat;
        background-size: 12px auto;
    }
    .introSideMenu>ul a:hover{
        opacity: 0.6;
    }
    /*본문시작*/
    .content{
        width: 100%;
        animation-name: sectionShow;
        animation-delay: 1s;
        animation-duration: 0.5s;
        animation-fill-mode: forwards;
        opacity: 0;
    }
    @keyframes sectionShow {
        0%   {opacity: 0;}
        40%   {opacity: 1;}
        45%   {opacity: 0;}
        50%   {opacity: 1;}
        95%   {opacity: 0;}
        100%   {opacity: 1;}  
    }    
    /*본문타이틀*/
    .contentTitile{
        text-align: center;
        padding: 60px 0 0 0;
    }
    .contentTitile>span{
        font-size: 14px;
        font-weight: 300;
        line-height: 20px;
        padding: 0 15px;
        background-color: #2C50FA;
        color: #fff;
        border-radius: 20px;
    }
    .contentTitile>h3{
        font-size: 26px;
        font-weight: bold;
        padding: 23px 0 0 0;
        color: #333;
    }
    .contentTitile>p{
        font-size: 14px;
        font-weight: 300;
    }
    /*본문section*/
    .contentBox{
        width: 100%;
        padding: 0 70px;
        box-sizing: border-box;
    }
    .contentBox>section{
        width: 100%;
        padding: 70px 0 90px 0;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        border-bottom: 2px solid #E5BE07;
    }
    .ctBoxPhoto{
        width: 50%;
        height: 450px;
    }
    .cbp01{
        background: #fff url('../assets/img/renewal/project_mock_02.png')center no-repeat;
        background-size: contain;
    }
    .cbp02{
        background: #fff url('../assets/img/renewal/project_mock_01.png')center no-repeat;
        background-size: contain;
    }
    .cbp03{
        background: #fff url('../assets/img/renewal/project_mock_03.png')center no-repeat;
        background-size: contain;
    }
    .ctBoxInfo{
        width: 50%;
        box-sizing: border-box;
        padding: 0 0 0 30px;
        color: #333;
        font-size: 15px;
    }
    .ctBoxInfo>h4{
        font-size: 18px;
        font-weight: 500;
        margin-bottom: 35px;
    }
    .ctBoxInfo>h4>span{
        font-size: 42px;
        font-weight: bold;
        color: #2C50FA;
        padding-right: 20px;
        vertical-align: middle;
    }
    .ctBoxInfo>p{
        line-height: 20px;
    }
    .ctBoxInfo>p>span{
        display: inline-block;
        width:82px;
        font-weight: 500;
        color: #2C50FA;
    }
    .ctBoxInfoTxt{
        padding: 35px 0;
    }
    .ctBoxDemoBtn,.ctBoxReposBtn,.ctBoxMockupBtn{
        display: inline-block;
        text-align: center;
        width: 85px;
        line-height: 24px;
        border: none;
        border-radius: 20px;
        color: #fff;
        margin-right: 10px;
        cursor: pointer;
        transition: 0.2s;
    }
    .ctBoxMockupBtn{
        background-color:#E5BE07;
        color: #333;
        cursor: pointer;
    }
    .ctBoxDemoBtn,.ctBoxReposBtn{
        background-color: #2C50FA;
        color: #fff;
    }           
    .ctBoxDemoBtn:hover, .ctBoxReposBtn:hover{
        background-color: #7f95ff;
    }
    .ctBoxMockupBtn:hover{
        background-color:#ffe677;
    }
    /**/
    .ctBoxSkill{
        width: 100%;
    }
    .ctBoxSkill table{
        width: 100%;
    }
    .ctBoxSkill th{
        font-weight: 500;
        border-bottom: 1px solid #333;
        text-align: left;
        padding: 35px 0 15px 10px;
    }
    .ctBoxSkill tr:nth-of-type(2) td{
        padding-top: 15px;
    }
    .ctBoxSkill td{
        line-height: 25px;
        text-align: left;
        padding: 0 0 0 10px;
        color: #929292;
        font-weight: 300;
    }
    .tb_cate>span{
        display: inline-block;
        font-size: 14px;
        line-height: 20px;
        vertical-align: middle;
        padding: 0 10px;
        border-radius: 4px;
        color: #fff;
        font-weight: 400;
    }
    .tb_c_ejs>span{
        background-color: #2C50FA;
    }
    .tb_c_css>span{
        background-color: #EE9123;
    }
    .tb_c_js>span{
        background-color: #51AA0A;
    }
    .tb_c_mysql>span{
        background-color: #F14848;
    }
    /*목업클릭시 상세페이지 .introMain에 relative*/
    .contentDetail{
        display: none;
        position: absolute;
        top:0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #fff;
        z-index: 999;
        transition: 0.3s;
    }
    .contentDtWrap{
        width: 100%;
        height: 100%;
        position: relative;
        overflow-y: scroll;
        scrollbar-color: #2C50FA rgba(255,255,255,0);
        scrollbar-width: thin;
    }
    .contentDtWrap::-webkit-scrollbar {
        width: 5px;
    }
    .contentDtWrap::-webkit-scrollbar-thumb {
        background-color: #2C50FA;
    }
    .contentDtWrapClose{
        display: block;
        width: 40px;
        height: 40px;
        position:sticky;
        top: 40px;
        left: calc(100% - 60px);
        cursor: pointer;
        background: url('../assets/img/other/other_close.png')center no-repeat;
        background-size: 25px auto;
    }
    .contentDtWrapClose:hover{
        opacity: 0.6;
    }
    .contentDtEl{
        width: 100%;
        display: none;
        text-align: center;
        color: #333;
    }
    .contentDtEl>img{
        display: block;
        margin: auto;
        width: 900px;
    }
    .contentDtEl>h4{
        font-size: 20px;
        font-weight: bold;
        padding: 80px 0 0 0;
    }
    .contentDtEl>p{
        font-size: 15px;
        padding: 10px 0 40px 0;
    }
    .contentDtEl>img{
        display: block;
        margin: auto;
    }

    /*----------------------------------------------------------------------------------------------- */
    @media screen and (max-width: 1300px){   
        main{
            padding: calc(50vh - 400px) 50px 0 50px;
        } 
        #introWrap{
            width: 100%;
        }

        
    }
    /*---------------------------------------------------태블릿-------------------------------------------- */
    @media screen and (max-width: 950px){   
         main{
            padding: 10vh 15px 10vh 15px;
        }
        .introMain{
            height: 80vh;
            scrollbar-width: none;
        }
        .introMain::-webkit-scrollbar {
            width: none;
        }
        #introWrap{
            height: 100%;
        }
        /*SVG~~~*/
        .project_bg_line{
            position: absolute;
            left: -400px;
            bottom: -100px;
        }    
        .project_bg_line>svg{
            width: 1850px;
        }
        /*본문section*/
        .contentBox{
            padding: 0 50px;
        }
        .contentBox>section{
            padding: 45px 0 65px 0;
            display: block;
        }
        .ctBoxPhoto{
            width: 100%;
        }
        .ctBoxInfo{
            width: 100%;
            padding: 30px 10px 0 10px;
        }
        .ctBoxInfo>h4{
            font-size: 18px;
            font-weight: 500;
            margin-bottom: 35px;
        }
        .ctBoxInfoTxt{
            padding: 30px 0;
        }
        /**/
        .ctBoxSkill{
            width: 100%;
            padding: 30px 0 0 0;
        }
        .ctBoxSkill table{
            width: 100%;
        }
        .ctBoxSkill th{
            border-top: 1px solid #333;
            border-bottom: 1px solid #333;
            padding: 10px 0 10px 10px;
        }
        .ctBoxSkill td{
            vertical-align:middle;
            word-break: break-all;
        }
        /* */
        .ctBoxDemoBtn,.ctBoxReposBtn,.ctBoxMockupBtn{
            width: 75px;
            margin-right: 7px;
            font-size: 14px;
        }
        /*목업 이미지 와이드 */
        .contentDtEl>img{
            width: 100%;
        }
    
    }
    /*---------------------------------------------------모바일-------------------------------------------- */
    @media screen and (max-width: 650px){   
        /*SVG~~~*/
        .project_bg_line{
            position: absolute;
            left: -400px;
            bottom: -100px;
        }    
        .project_bg_line>svg{
            width: 1750px;
        }
         /*본문section*/
        .contentBox{
            padding: 0;
        }
        .contentBox>section{
            padding: 40px 0 50px 0;
            display: block;
        }
        .ctBoxInfo{
            width: 100%;
            padding: 30px 30px 0 30px;
        }
        /**/
        .ctBoxSkill{
            width: 100%;
            padding: 30px 30px 0 30px;
            box-sizing: border-box;
        }
        .ctBoxSkill table{
            width: 100%;
        }
        .ctBoxSkill th{
            border-top: 1px solid #333;
            border-bottom: 1px solid #333;
            padding: 10px 0 10px 10px;
        }
        .ctBoxSkill td{
            vertical-align:middle;
        }

    
    }

</style>
